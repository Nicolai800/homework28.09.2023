public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        int x = 345;
        int a = x / 100;
        int b = x / 10 % 10;
        int c = x % 10;
        System.out.println(x + "->" + a + ", " + b + ", " + c);

        int y = 987;
        int d = y / 100;
        int f = y / 10 % 10;
        int g = y % 10;
        System.out.println(y + "->" + d + ", " + f + ", " + g);
    }
}