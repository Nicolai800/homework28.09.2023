public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

    // Исследование № 1
        byte b = 127;
        System.out.println(b); // Результат 127.
        b++;
        System.out.println(b); // Результат -128.
        byte b1 = -128;
        System.out.println(b1);
        b1--;
        System.out.println(b1);
        short s = 32767;
        System.out.println(s); // Результат 32767.
        s++;
        System.out.println(s); // Результат -32768.
        int i = 2147483647;
        System.out.println(i); // Результат 2147483647.
        i++;
        System.out.println(i); // Результат -2147483648.
        // В результате получается противоположное (минимальное) значение.

    // Исследование № 2
        int n = 3859;
        float n1 = 233.15f;
        System.out.println(n*n1);
        // Получается дробный тип

    // Исследование № 3
        char z = 'A';
        System.out.println(z);
        z++;
        System.out.println(z);
        //Да, char это и числовой тип тоже (гибридный тип).
        // Так как каждому символу соответствует число — числовой код символа.






    }
}


